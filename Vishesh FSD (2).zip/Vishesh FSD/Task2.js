// write a program to design a feedback form contains feild name email feedback along with radio button and comment box and submit button and the save submitted form data to data base collection feedback now by submitting a form display sucsess massage on a next page called /fetch feedback data also give a link to display all submitted feedback from the data base collection on /display-feedback page
const mg = require("mongoose")
// v = require("validator")
ex = require("express")
app = ex()
mg.connect("mongodb://127.0.0.1:27017/test1")
.then(()=>{console.log("Connected")})
.catch((err)=>{console.log(err)})
mg.pluralize(null)
const schema = mg.Schema({
    name:{type:String,require:true},
    email:String,
    feedback:{type:String,require:true},
    comment:String
})
const feedback = mg.model("feedback",schema)
app.use(ex.static(__dirname,{index:"task2.html"}))
app.get("/feedback_data",(req,res)=>{
    const pd = new feedback({
        name:req.query.name,
        email:req.query.email,
        feedback:req.query.x1,
        comment:req.query.comment
    })
    pd.save()
    res.send("Record Inserted<a href='/display_feedback'>Display Feedback</a>")
})

app.get("/display_feedback",async(req,res)=>{
    const d = await feedback.find()
    res.write(`<table border="1px solid black">
        <tr>
        <th>Name</th>
        <th>Feed Back</th>
        <th>Comment</th>
        </tr>`)
        d.map((data)=>{
            res.write(`<tr>
                <td>${data.name}</td>
                <td>${data.feedback}</td>
                <td>${data.comment}</td>
                </tr>`)
        })
        res.write("</table")
        res.send()
})
app.listen(8000)