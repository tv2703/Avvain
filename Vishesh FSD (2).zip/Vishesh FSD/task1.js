const mg = require("mongoose")
mg.connect("mongodb://127.0.0.1:27017/test1")
.then(()=>{console.log("Success")})
.catch((err)=>{console.log(err)})
const myschema=new mg.Schema({
    name:{type:String,required:true},
    surname:String,
    age:Number,
    active:Boolean,
    // date:{type:Date,default:new Date()}
})
const person = new mg.model("Task1",myschema)

const createdoc = async()=>{
    try {
        const data = new person({name:"test",surname:"test1",age:37,active:true})
        const data1 = new person({name:"hi",surname:"hi1",age:37,active:true})
        const data2 = new person({name:"hello",surname:"hello1",age:37,active:true})
        const data3 = new person({name:"hello",surname:"hello11",age:37,active:false})
        result = await person.insertMany([data,data1,data2,data3])
        console.log(result)
    }
    catch(err) {
        console.log(err)
    }
}
createdoc()