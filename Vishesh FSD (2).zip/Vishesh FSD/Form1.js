var expr = require('express')
var app = expr()
const mg = require('mongoose')
const val = require("validator")
mg.connect("mongodb://127.0.0.1:27017/registrationform")
const myschema = new mg.Schema({
    Username: { type: String, required: true },
    Email: { type: String, required: true },
    Gender: { type: String, required: true },
    Phone_No: {
        type: Number, required: true
    },
    Age: {
        type: Number, required: true
    }

})
const person = new mg.model("data1", myschema)
app.use(expr.static(__dirname, { index: "Form1.html" }))
app.get("/signup", (req, res) => {
    const pd = new person({ Username: req.query.uname, Email: req.query.email, Age: req.query.age, Gender: req.query.x1, Phone_No: req.query.phone })
    pd.save()
    res.send("Record Inserted")
}).listen(3000)