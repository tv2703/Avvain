const mg = require("mongoose")
mg.connect("mongodb://127.0.0.1:27017/test1")
.then(()=>{console.log("Success")})
.catch((err)=>{console.log(err)})
const myschema=new mg.Schema({
    name:{type:String,required:true},
    surname:String,
    age:Number,
    active:Boolean,
    date:{type:Date,default:new Date()}
})
// mg.pluralize(null)
const person = new mg.model("saumya01",myschema)
// const x = new mg.model("man",myschema)
// const persondata = new person({name:"abc",surname:"pqr",age:22,active:true})
// persondata.save()
// const persondata2 = new person({name:"mno",year:2023,age:3})
// persondata2.save()
// const persondata3 = new person({age:4,active:true})
// persondata3.save()
const createdoc = async()=>{
    try {
        const persondata = new person({name:"abc",surname:"pqr",age:22,active:true})
        // const result = await persondata.save()
        const persondata1 = new person({name:"xyz",surname:"abc",age:2,active:false})
        // persondata1.save()
        result = await person.insertMany([persondata,persondata1])
        console.log(result)

    }
    catch(err) {
        console.log(err)
    }
}
createdoc()