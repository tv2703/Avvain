mg = require("mongoose")
// v = require("validator")
ex = require("express")
app = ex()
mg.connect("mongodb://127.0.0.1:27017/registrationform")
.then(()=>{console.log("Connected")})
.catch((err)=>{console.log(err)})
myschema = new mg.Schema({
    uname:{type:String,required:true},
    password:{type:String,required:true}
})
const person = new mg.model("data1",myschema)
app.use(ex.static(__dirname,{index:"Form.html"}))
app.get("/signup",(req,res)=>{
    const pd = new person({uname:req.query.uname,password:req.query.pwd})
    pd.save()
    res.send("Record Inserted")
}).listen(3000)