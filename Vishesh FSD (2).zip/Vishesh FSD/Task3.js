// find a person by there name in mongodb database and update their age using find by id by also return updated document
const mg = require("mongoose")
// v = require("validator")
ex = require("express")
app = ex()
mg.connect("mongodb://127.0.0.1:27017/test1")
.then(()=>{console.log("Connected")})
.catch((err)=>{console.log(err)})
mg.pluralize(null)
