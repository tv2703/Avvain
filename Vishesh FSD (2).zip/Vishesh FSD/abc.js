const mg = require("mongoose")
mg.connect("mongodb://127.0.0.1:27017/test1")
.then(()=>{console.log("Success")})
.catch((err)=>{console.log(err)})
const myschema=new mg.Schema({
    name:{type:String,required:true},
    surname:String,
    age:Number,
    active:Boolean,
    date:{type:Date,default:new Date()}
})
mg.pluralize(null)
const person = new mg.model("person",myschema)
// const x = new mg.model("man",myschema)
// const persondata = new person({name:"abc",surname:"pqr",age:22,active:true})
// persondata.save()
// const persondata2 = new person({name:"mno",year:2023,age:3})
// persondata2.save()
// const persondata3 = new person({age:4,active:true})
// persondata3.save()
// const persondata1 = new person({name:53})
// persondata1.save()