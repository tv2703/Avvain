mg = require("mongoose")
v = require("validator")
mg.connect("mongodb://127.0.0.1:27017/test1")
    .then(() => { console.log("Connected") })
    .catch((err) => { console.log(err) })

schema = new mg.Schema({
    // Basic Validator
    name: {
        type: String,
        required: true,
        trim: true,
        minlength: [3, "Minimum 3 length required"],
        maxlength: [7, "Maximum 7 length required"]
    },
    gender: {
        type: String,
        required: true,
        uppercase: true,
        enum: ["MALE", "FEMALE"]
    },
    //Custom Validator
    age: {
        type: Number,
        validate(v1) {
            if (v1 < 0) {
                throw new Error("Age must be positive.")
            }
        }
    },
    // Validator Module
    email: {
        type: String,
        required: true,
        validate(val) {
            if (!v.isEmail(val)) {
                throw new Error("Enter Valid Email.")
            }
        }
    }
})

val = new mg.model('val', schema)

const pd = new val({ name: 'Sam', age: 22, email: 'kdck@gmail.com', gender: 'MALE' })
pd.save().then(() => console.log("Saved successfully")).catch((err) => console.log(err))