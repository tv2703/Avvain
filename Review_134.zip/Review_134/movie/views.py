from django.shortcuts import render
from django.http import HttpResponse
from .models import Movie
# Create your views here.
def home(request):
    searchterms = request.GET.get("searchMovie")
    if searchterms:
        movie = Movie.objects.filter(title__icontains=searchterms)
    else:
        movie = Movie.objects.all()
    return render(request,"home.html",{"searchterms":searchterms,"movie":movie})
    
def about(request):
    return HttpResponse("<h1>About Page</h1>")

def signup(request):
    searchmail = request.GET.get("mail")
    return render(request,"signup.html",{"searchmail":searchmail})