from django.shortcuts import render
from django.http import HttpResponse
# Create your views here.
def home(request):
    searchterms = request.GET.get("searchMovie")
    return render(request,"home.html",{"searchterms":searchterms})
def about(request):
    return HttpResponse("<h1>About Page</h1>")

def signup(request):
    searchmail = request.GET.get("mail")
    return render(request,"signup.html",{"searchmail":searchmail})
