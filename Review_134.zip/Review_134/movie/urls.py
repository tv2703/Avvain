from django.contrib import admin
from django.urls import path,include
from movie.views import home as movie
from movie.views import about as about
from movie import views

urlpatterns = [
    path('admin/', admin.site.urls),
    path("",views.home),
    path("about/",views.about),
    path("signup/",views.signup,name="signup")
]